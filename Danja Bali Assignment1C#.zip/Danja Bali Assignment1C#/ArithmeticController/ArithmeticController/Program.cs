﻿
using System;
namespace ArithmeticController
{

    class Program
    {
        // Method to check integer values pass by reference
        public static void Arithmetics(int x, int y, ref int addition, ref int subtraction, ref int product, ref int division)
        {
            addition = x + y;
            subtraction = x - y;
            product = x * y;
            division = x / y;
        }
        //Method to check double values pass by reference
        public static void Arithmetics(double x, double y, ref double addition, ref double subtraction, ref double product, ref double division)
        {
            addition = x + y;
            subtraction = x - y;
            product = x * y;
            division = x / y;
        }
        static void Main(string[] args)
        {
            //  Integer checker
            int x = 6, y = 2, addition = 0, subtraction = 0, product = 0, division = 0;
            Arithmetics(x, y, ref addition, ref subtraction, ref product, ref division);
            Console.WriteLine("Sample Integer Values \n");
            Console.WriteLine(x + " + " + y + " = " + addition + "\n");
            Console.WriteLine(x + " - " + y + " = " + subtraction + "\n");
            Console.WriteLine(x + " * " + y + " = " + product + "\n");
            Console.WriteLine(x + " / " + y + " = " + division + "\n");

            // Double checker
            Console.WriteLine();
            double a = 5.5, b = 2.2, additionD = 0.00, subtractionD = 0.00, productD = 0.00, divisionD = 0.00;
            Arithmetics(a, b, ref additionD, ref subtractionD, ref productD, ref divisionD);
            Console.WriteLine("Sample Double Values  \n");
            Console.WriteLine(a + " + " + b + " = " + additionD + "\n");
            Console.WriteLine(a + " - " + b + " = " + subtractionD + "\n");
            Console.WriteLine(a + " * " + b + " = " + productD + "\n");
            Console.WriteLine(a + " / " + b + " = " + divisionD + "\n");
        }
    }
}