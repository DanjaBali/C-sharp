﻿using System;

namespace GradeBook
{

    class Program
    {
        static void Main(string[] args)
        {
            //Array of objects
            Gradebook[] courses = new Gradebook[3];
            int[] grades = { 70, 80, 55 };

            //Add values for each 
            courses[0] = new AmericanGradebook("American Course", grades);

            courses[1] = new BritishGradebook("British Course", grades);

            courses[2] = new AlbanianGradebook("Albanian Course", grades);

            //Display details

            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("------------------------------------------ ");
                Console.WriteLine("Course Name: " + courses[i].GetCourseName);
                Console.WriteLine("Credit Hours: " + courses[i].GetCredits);
                Console.WriteLine("Average: " + courses[i].GetCourseAverage());
                Console.WriteLine("Number of Passes: " + courses[i].GetNumberOfPasses());
                Console.WriteLine("Number of Hours: " + courses[i].GetNumberOfHours());
                if (courses[i].GetType().Name == "BritishGradebook")
                {
                    BritishGradebook b = (BritishGradebook)(courses[i]);
                    Console.WriteLine("Number of distinctions: " + b.GetNumberOfDistinctions());
                }
                Console.WriteLine();
            }
        }
    }
    //Base class
    public abstract class Gradebook
    {
        private string courseName;
        private decimal credits;
        protected int[] grades;
        //Constructor1
        public Gradebook(string courseName)
        {
            this.courseName = courseName;
            credits = 0;
        }
        //Constructor2
        public Gradebook(string courseName, int[] grades)
        {
            this.courseName = courseName;
            credits = 0;
            this.grades = new int[grades.Length];
            for (int i = 0; i < grades.Length; i++)
            {
                this.grades[i] = grades[i];
            }
        }
        public double GetCourseAverage()
        {
            double average = 0;
            if (grades.Length == 0)
            {
                return -1;
            }
            else
            {
                for (int i = 0; i < grades.Length; i++)
                {
                    double val = Decimal.ToDouble(credits);
                    val *= grades[i];
                    average += val;
                }
                return average / (Convert.ToDouble(credits) * grades.Length);
            }
        }
        //Setters
        public string GetCourseName
        {
            get
            {
                return courseName;
            }
            set
            {
                courseName = value;
            }
        }
        public decimal GetCredits
        {
            get { return credits; }
            set
            {
                if (value < 0)
                {
                    throw new ArgumentOutOfRangeException("Credits shouldn't be negative!!!");
                }
                else
                {
                    credits = value;
                }
            }
        }
        //Abstarct methods
        public abstract int GetNumberOfPasses();
        public abstract int GetNumberOfHours();
    }
    //Subclass inherited from base class
    public class AmericanGradebook : Gradebook
    {
        //Constructor
        public AmericanGradebook(string courseName, int[] grades) : base(courseName, grades)
        {
            GetCredits = 15;
        }
        //Abstarct methods implementation
        public override int GetNumberOfHours()
        {
            return Decimal.ToInt32(GetCredits) * grades.Length;
        }

        public override int GetNumberOfPasses()
        {
            int count = 0;
            for (int i = 0; i < grades.Length; i++)
            {
                if (grades[i] >= 70)
                {
                    count++;
                }
            }
            return count;
        }
    }
    //Subclass inherited from base class
    public class AlbanianGradebook : Gradebook
    {
        //Constructor
        public AlbanianGradebook(string courseName, int[] grades) : base(courseName, grades)
        {
            GetCredits = Convert.ToDecimal(7.5);
        }
        //Abstarct methods implementation
        public override int GetNumberOfHours()
        {
            return Decimal.ToInt32(GetCredits) * grades.Length;
        }

        public override int GetNumberOfPasses()
        {
            int count = 0;
            for (int i = 0; i < grades.Length; i++)
            {
                if (grades[i] >= 45)
                {
                    count++;
                }
            }
            return count;
        }
    }
    //Subclass inherited from base class
    public class BritishGradebook : Gradebook
    {
        //Constructor
        public BritishGradebook(string courseName, int[] grades) : base(courseName, grades)
        {
            GetCredits = Convert.ToDecimal(3.5);
        }
        //Abstarct methods implementation
        public override int GetNumberOfHours()
        {
            return Decimal.ToInt32(GetCredits) * grades.Length;
        }

        public override int GetNumberOfPasses()
        {
            int count = 0;
            for (int i = 0; i < grades.Length; i++)
            {
                if (grades[i] >= 50)
                {
                    count++;
                }
            }
            return count;
        }
        //Method to get distictions count
        public int GetNumberOfDistinctions()
        {
            int count = 0;
            for (int i = 0; i < grades.Length; i++)
            {
                if (grades[i] >= 70)
                {
                    count++;
                }
            }
            return count;
        }
    }
}