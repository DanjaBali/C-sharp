﻿//Program by Danja Bali
using System;

namespace AirTrafficControler
{
    enum FlightStatus //FlightStatus enumeration to represent diffrent flight status. 

    {   // Key attributes of a Flight in an air-traffic-control system
        Parked = 1,
        TaxiingFromGate = 2,
        WaitingToTakeOff = 3,
        TakingOff = 4,
        Climbing = 5,
        ApproachingRunway = 6,
        Landing = 7,
        TaxxingToGate = 8,
        AtGate = 9,
        ChangingAltitude = 10
    }

    class Airplane // Class Airplane
    {   //set and get functions to manipulate attributes 
        public string Make { get; set; }
        public string Model { get; set; }
        public string Carrier { get; set; }
        public Airplane(string make, string model, string carrier)
        {
            Make = make;
            Model = model;
            Carrier = carrier;
        }
        public void DisplayAirplaneInformation() //Method to display attributes such as Airline Carrier, make, and model, 
        {
            Console.WriteLine(" Airline/Carrier  :" + Carrier);
            Console.WriteLine(" Make             : " + Make);
            Console.WriteLine(" Model            : " + Model);
           
        }
    }

    class Flight // Class flight and the key attributes 
    {//set and get functions to manipulate attributes 
        public FlightStatus Status { get; set; }
        public Airplane Airplane { get; set; }
        public int    Altitude { get; set; }
        public string Direction { get; set; }
        public string DepartureTime { get; set; }
        public string ArrivalTime { get; set; }
        public string Origin { get; set; }
        public string Destination { get; set; }
        public string CurrentAirSpeed { get; set; }
        public string FlightNumber { get; set; }
        
        public Flight(FlightStatus status, Airplane airplane, int altitude, string direction, string departureTime, string arrivalTime, string origin, string destination, string Speed,string flightnumber)
        {
            Status = status;
            Airplane = airplane;
            Altitude = altitude;
            Direction = direction;
            DepartureTime = departureTime;
            ArrivalTime = arrivalTime;
            Origin = origin;
            Destination = destination;
            CurrentAirSpeed = Speed;
            FlightNumber = flightnumber;

        }
        public void ChangeFlightStatus(int status_code) //Method for Flight Status changes
        {
            switch (status_code)// swith case 
            {
                case 1:
                    Status = FlightStatus.Parked;
                    Console.WriteLine(" [Notice] Flight Status updated to PARKED");
                    break;
                case 2:
                    Status = FlightStatus.TaxiingFromGate;
                    Console.WriteLine(" [Notice] Flight Status updated to TAXXING FROM GATE");
                    break;
                case 3:
                    Status = FlightStatus.WaitingToTakeOff;
                    Console.WriteLine(" [Notice] Flight Status for" + Airplane.Carrier + ": " + FlightNumber + " updated to WAITING TO TAKE OFF");
                    break;
                case 4:
                    Status = FlightStatus.TakingOff;
                    Console.WriteLine(" [Notice] Flight Status for " + Airplane.Carrier + ": " + FlightNumber + " updated to TAKING OFF");
                    break;
                case 5:
                    Status = FlightStatus.Climbing;
                    Console.WriteLine(" [Notice] Flight Status for " + Airplane.Carrier + ": " + FlightNumber + " updated to CLIMBING");
                    break;
                case 6:
                    Status = FlightStatus.ApproachingRunway;
                    Console.WriteLine(" [Notice] Flight Status for " + Airplane.Carrier + ": " + FlightNumber + " updated to APPROACHING RUNWAY");
                    break;
                case 7:
                    Status = FlightStatus.Landing;
                    Console.WriteLine(" [Notice] Flight Status for " + Airplane.Carrier + ": " + FlightNumber + " updated to LANDING");
                    break;
                case 8:
                    Status = FlightStatus.TaxxingToGate;
                    Console.WriteLine(" [Notice] Flight Status for " + Airplane.Carrier+ ": " + FlightNumber + " updated to TAXIING TO GATE");
                    break;
                case 9:
                    Status = FlightStatus.TaxxingToGate;
                    Console.WriteLine("\n" + Airplane.Carrier + " " + FlightNumber + " has descend to 12000 feet " );
                    break;
                default:
                    Console.WriteLine(" [Error] Wrong flight status code.");
                    return;
            }
        }

        public void SetAltitude(int altitude) //Method to print states of altitude
        {
            Console.WriteLine(" [Warning] Changing altitude.....");
            int temp2 = Altitude;
            FlightStatus temp = Status;
            Status = FlightStatus.ChangingAltitude;
            Console.WriteLine(" [Notice] Status updated!");
            Altitude = altitude;
            Console.WriteLine(" [Notice] Flight altitute increased to " + Altitude +" feet");
            Status = temp;
            Console.WriteLine(" [Notice] Status restored after changing altitude");
            Console.WriteLine(" [Notice] " + Airplane.Carrier + " " + FlightNumber + "" + " changing altitude from " + temp2 + " to " + altitude +" feet.");
        }

        public void changeAltitude(int altitude) //Method to descend the altitude 
        {

            Altitude = altitude;
            Console.WriteLine( Airplane.Carrier + " " + FlightNumber + " has descend to " + altitude + " feet. " + "\n");

        }

        public void PrintFlightDetails() // Void method to print attributes
        {
            Console.WriteLine(" Airplane Information \n"+ "__________________________________________________________________");
            Airplane.DisplayAirplaneInformation();
            Console.WriteLine(" Altitude         : " + Altitude);
            Console.WriteLine(" Direction        : " + Direction);
            Console.WriteLine(" Departure Time   : " + DepartureTime);
            Console.WriteLine(" Arrival Time     : " + ArrivalTime);
            Console.WriteLine(" Origin           : " + Origin);
            Console.WriteLine(" Destination      : " + Destination);
            Console.WriteLine(" CurrentAirSpeed  : " + CurrentAirSpeed);
            Console.WriteLine(" Flight Number    : " + FlightNumber +"\n"+ "__________________________________________________________________");
            
        }
    }

    class AirTrafficControl //Air Traffic Controller class
    {
        public static Flight flight1;
        public static Flight flight2;
        public static Flight flight3;

        static void GetAllFlightInformation() //Method to show the info for each Airplane flight
        {
            flight1.PrintFlightDetails();
            Console.WriteLine();
            flight2.PrintFlightDetails();
            Console.WriteLine();
            flight3.PrintFlightDetails();
            Console.WriteLine();
        }

        static void InitializeSimulation() //Three Flight objects representing planes that are currently flying or preparing to fly
        {
            flight1 = new Flight(FlightStatus.ApproachingRunway, new Airplane("Short-Haul", "747", " Albanian Airways"), 1700, "SOUTH", "08-May-21 8:30:15 PM", "04:01:00", "TIA", "NYC", "30 mph ", "EA1");
            flight2 = new Flight(FlightStatus.TakingOff, new Airplane("Mid-Size Jets", "B300", " United Airlines"), 2000, "East", "08-May-21 8:30:15 PM", "04:01:00", "JFK", "ZRH", "15 mph ", "EA2");
            flight3 = new Flight(FlightStatus.Climbing, new Airplane("Light Jets", "A220", " British Airways"), 5000, "SOUTH", "08-May-21 8:30:15 PM", "04:01:00", "LCY", "BKK", "25 mph ", "QA3");
        }

        static void Main(string[] args)
        {
            Console.WriteLine(" \n Hello, Welcome to Air-Traffic-Control Simulator!");
            Console.WriteLine(" Starting Simulation...\n");
            InitializeSimulation();
            GetAllFlightInformation();
            int new_Altitude = 25000;
            Console.WriteLine("" + flight1.Airplane.Carrier + ": " + flight1.FlightNumber + " now climbing to an altitude of " + new_Altitude +" feet" );
            flight1.SetAltitude(new_Altitude);
            Console.WriteLine( ""+ flight1.Airplane.Carrier+": " + flight1.FlightNumber + " now changing status to CLIMBING.");
            flight1.ChangeFlightStatus(5); // status 5 is climbing in enum list
            Console.WriteLine("" + flight1.Airplane.Carrier + " flight status for " + flight1.FlightNumber + " is to be descend to 12000 feet.");
            flight1.changeAltitude(12000);
            Console.WriteLine("\n"+ "__________________________________________________________________ ");

        }
    }
}
